package com.example.trock.action;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.example.trock.service.WorklogService;

public class TrockOverviewAction extends JiraWebActionSupport {

    @Override
    public String doDefault() {
        return SUCCESS;
    }

    @Override
    public String doExecute() {
        return SUCCESS;
    }

    public boolean isManager() {
        WorklogService svc = ComponentAccessor.getOSGiComponentInstanceOfType(WorklogService.class);
        return svc != null && svc.isManager(getLoggedInUser());
    }
}
