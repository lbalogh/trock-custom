package com.example.trock.rest;

import com.example.trock.config.TrockConfig;
import com.example.trock.config.TrockConfigService;
import com.example.trock.service.WorklogService;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Named
@Path("/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class TrockResource {

    private final WorklogService worklogService;
    private final TrockConfigService configService;

    @Inject
    public TrockResource(WorklogService worklogService, TrockConfigService configService) {
        this.worklogService = worklogService;
        this.configService = configService;
    }

    /** GET /rest/trock/1.0/worklogs?from=2026-04-01&to=2026-04-30&userKey=... */
    @GET
    @Path("worklogs")
    public Response list(@QueryParam("from") String from,
                         @QueryParam("to") String to,
                         @QueryParam("userKey") String userKey) {
        try {
            LocalDate f = LocalDate.parse(from);
            LocalDate t = LocalDate.parse(to);
            List<WorklogService.WorklogDto> result = worklogService.getWorklogs(userKey, f, t);
            return Response.ok(result).build();
        } catch (SecurityException se) {
            return Response.status(Response.Status.FORBIDDEN).entity(err(se.getMessage())).build();
        } catch (Exception e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(err(e.getMessage())).build();
        }
    }

    public static class LogRequest {
        public String issueKey;
        public long seconds;
        public String comment;
        public String startedIso; // e.g. 2026-04-09T10:00:00.000Z
    }

    /** POST /rest/trock/1.0/worklogs   body: LogRequest */
    @POST
    @Path("worklogs")
    public Response create(LogRequest req) {
        try {
            Date started = req.startedIso != null
                    ? Date.from(java.time.Instant.parse(req.startedIso))
                    : new Date();
            WorklogService.WorklogDto dto = worklogService.logWork(req.issueKey, req.seconds, req.comment, started);
            return Response.ok(dto).build();
        } catch (SecurityException se) {
            return Response.status(Response.Status.FORBIDDEN).entity(err(se.getMessage())).build();
        } catch (Exception e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(err(e.getMessage())).build();
        }
    }

    /** GET /rest/trock/1.0/config  (admin) */
    @GET
    @Path("config")
    public Response getConfig() {
        return Response.ok(configService.load()).build();
    }

    /** PUT /rest/trock/1.0/config  (admin) */
    @PUT
    @Path("config")
    public Response putConfig(TrockConfig cfg) {
        // NOTE: enforce admin permission here (see TrockAdminAction which already gates the UI).
        configService.save(cfg);
        return Response.ok(cfg).build();
    }

    private static Object err(String msg) {
        return java.util.Collections.singletonMap("error", msg);
    }
}
