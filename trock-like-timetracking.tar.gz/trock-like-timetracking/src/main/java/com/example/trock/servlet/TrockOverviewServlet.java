package com.example.trock.servlet;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.templaterenderer.TemplateRenderer;
import com.example.trock.service.WorklogService;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

// PAS de @Named, PAS de @Inject — Jira instancie les servlets lui-même via le plugin descriptor
public class TrockOverviewServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        JiraAuthenticationContext ctx = ComponentAccessor.getJiraAuthenticationContext();
        ApplicationUser user = ctx.getLoggedInUser();

        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp?os_destination=" +
                java.net.URLEncoder.encode(req.getRequestURI(), "UTF-8"));
            return;
        }

        WorklogService svc = ComponentAccessor.getOSGiComponentInstanceOfType(WorklogService.class);
        boolean isManager = svc != null && svc.isManager(user);

        TemplateRenderer renderer = ComponentAccessor.getOSGiComponentInstanceOfType(TemplateRenderer.class);

        Map<String, Object> context = new HashMap<>();
        context.put("isManager", isManager);
        context.put("user", user);
        context.put("contextPath", req.getContextPath());

        resp.setContentType("text/html;charset=UTF-8");
        renderer.render("/templates/overview.vm", context, resp.getWriter());
    }
}
