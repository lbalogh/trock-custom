package com.example.trock.config;

public class TrockConfig {
    /** Number of full months in the past where logging is forbidden (0 = no limit). */
    private int blockPreviousMonths;
    /** JQL query — any issue matching it will be blocked for logging. Empty = none. */
    private String blockJql;
    /** Name of the Jira group whose members can see other users' worklogs. */
    private String managerGroup;

    public int getBlockPreviousMonths() { return blockPreviousMonths; }
    public void setBlockPreviousMonths(int v) { this.blockPreviousMonths = v; }

    public String getBlockJql() { return blockJql; }
    public void setBlockJql(String v) { this.blockJql = v; }

    public String getManagerGroup() { return managerGroup; }
    public void setManagerGroup(String v) { this.managerGroup = v; }
}
