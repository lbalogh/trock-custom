package com.example.trock.action;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.permission.GlobalPermissionKey;
import com.atlassian.jira.security.GlobalPermissionManager;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.example.trock.config.TrockConfig;
import com.example.trock.config.TrockConfigService;

public class TrockAdminAction extends JiraWebActionSupport {

    private int blockPreviousMonths;
    private String blockJql;
    private String managerGroup;
    private boolean saved;

    private TrockConfigService configService() {
        return ComponentAccessor.getOSGiComponentInstanceOfType(TrockConfigService.class);
    }

    private boolean isAdmin() {
        GlobalPermissionManager gpm = ComponentAccessor.getGlobalPermissionManager();
        return getLoggedInUser() != null
                && gpm.hasPermission(GlobalPermissionKey.ADMINISTER, getLoggedInUser());
    }

    @Override
    public String doDefault() {
        if (!isAdmin()) return "error";
        TrockConfig c = configService().load();
        this.blockPreviousMonths = c.getBlockPreviousMonths();
        this.blockJql            = c.getBlockJql();
        this.managerGroup        = c.getManagerGroup();
        return INPUT;
    }

    @Override
    protected void doValidation() {
        if (!isAdmin()) addErrorMessage("Administrator permission required.");
        if (blockPreviousMonths < 0) addError("blockPreviousMonths", "Must be >= 0");
    }

    @Override
    public String doExecute() {
        if (!isAdmin()) return "error";
        TrockConfig c = new TrockConfig();
        c.setBlockPreviousMonths(blockPreviousMonths);
        c.setBlockJql(blockJql);
        c.setManagerGroup(managerGroup);
        configService().save(c);
        this.saved = true;
        return SUCCESS;
    }

    public int getBlockPreviousMonths() { return blockPreviousMonths; }
    public void setBlockPreviousMonths(int v) { this.blockPreviousMonths = v; }
    public String getBlockJql() { return blockJql; }
    public void setBlockJql(String v) { this.blockJql = v; }
    public String getManagerGroup() { return managerGroup; }
    public void setManagerGroup(String v) { this.managerGroup = v; }
    public boolean isSaved() { return saved; }
}
