package com.example.trock.service;

import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.worklog.Worklog;
import com.atlassian.jira.issue.worklog.WorklogImpl;
import com.atlassian.jira.issue.worklog.WorklogManager;
import com.atlassian.jira.jql.parser.JqlQueryParser;
import com.atlassian.jira.permission.ProjectPermissions;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.web.bean.PagerFilter;
import com.atlassian.query.Query;
import com.example.trock.config.TrockConfig;
import com.example.trock.config.TrockConfigService;
import javax.inject.Inject;
import javax.inject.Named;

import javax.inject.Named;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@Named
public class WorklogService {

    private final TrockConfigService configService;

    @Inject
    public WorklogService(TrockConfigService configService) {
        this.configService = configService;
    }

    public static class WorklogDto {
        public Long id;
        public String issueKey;
        public String issueSummary;
        public String authorKey;
        public String authorName;
        public long timeSpentSeconds;
        public String comment;
        public String startedIso;
    }

    /**
     * Fetch worklogs for a given user between two dates (inclusive).
     * Uses JQL (worklogAuthor + worklogDate) to narrow issues, then iterates each issue's worklogs.
     */
    public List<WorklogDto> getWorklogs(String targetUserKey, LocalDate from, LocalDate to) throws Exception {
        ApplicationUser caller = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser();
        if (caller == null) return Collections.emptyList();

        UserManager userManager = ComponentAccessor.getUserManager();
        ApplicationUser target = targetUserKey == null
                ? caller
                : userManager.getUserByKey(targetUserKey);
        if (target == null) return Collections.emptyList();

        // Authorisation: only managers (configured group) can see others
        if (!target.equals(caller) && !isManager(caller)) {
            throw new SecurityException("Not allowed to view worklogs of another user");
        }

        SearchService search = ComponentAccessor.getComponent(SearchService.class);
        JqlQueryParser parser = ComponentAccessor.getComponent(JqlQueryParser.class);
        String jql = String.format(
                "worklogAuthor = \"%s\" AND worklogDate >= \"%s\" AND worklogDate <= \"%s\"",
                target.getName(), from, to);
        Query query = parser.parseQuery(jql);

        List<Issue> issues = search.search(caller, query, PagerFilter.getUnlimitedFilter()).getResults();

        WorklogManager worklogManager = ComponentAccessor.getWorklogManager();
        PermissionManager pm = ComponentAccessor.getPermissionManager();
        Date fromDate = Date.from(from.atStartOfDay(ZoneId.systemDefault()).toInstant());
        Date toDate   = Date.from(to.plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant());

        List<WorklogDto> result = new ArrayList<>();
        for (Issue issue : issues) {
            if (!pm.hasPermission(ProjectPermissions.BROWSE_PROJECTS, issue, caller)) continue;
            for (Worklog wl : worklogManager.getByIssue(issue)) {
                if (wl.getAuthorKey() == null || !wl.getAuthorKey().equals(target.getKey())) continue;
                Date started = wl.getStartDate();
                if (started == null || started.before(fromDate) || !started.before(toDate)) continue;

                WorklogDto dto = new WorklogDto();
                dto.id = wl.getId();
                dto.issueKey = issue.getKey();
                dto.issueSummary = issue.getSummary();
                dto.authorKey = wl.getAuthorKey();
                dto.authorName = target.getDisplayName();
                dto.timeSpentSeconds = wl.getTimeSpent();
                dto.comment = wl.getComment();
                dto.startedIso = started.toInstant().toString();
                result.add(dto);
            }
        }
        return result;
    }

    /**
     * Create a worklog on the given issue, enforcing admin rules.
     */
    public WorklogDto logWork(String issueKey, long seconds, String comment, Date started) throws Exception {
        ApplicationUser caller = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser();
        if (caller == null) throw new SecurityException("Not logged in");

        Issue issue = ComponentAccessor.getIssueManager().getIssueObject(issueKey);
        if (issue == null) throw new IllegalArgumentException("Issue not found: " + issueKey);

        PermissionManager pm = ComponentAccessor.getPermissionManager();
        if (!pm.hasPermission(ProjectPermissions.WORK_ON_ISSUES, issue, caller)) {
            throw new SecurityException("No permission to log work on " + issueKey);
        }

        enforceRules(issue, started);

        WorklogImpl wl = new WorklogImpl(
                ComponentAccessor.getWorklogManager(),
                issue,
                null,                     // id (new)
                caller.getKey(),          // author
                comment,
                started,
                null, null,               // group, role
                seconds);

        Worklog created = ComponentAccessor.getWorklogManager().create(caller, wl, 0L, true);

        WorklogDto dto = new WorklogDto();
        dto.id = created.getId();
        dto.issueKey = issueKey;
        dto.issueSummary = issue.getSummary();
        dto.authorKey = caller.getKey();
        dto.authorName = caller.getDisplayName();
        dto.timeSpentSeconds = created.getTimeSpent();
        dto.comment = created.getComment();
        dto.startedIso = created.getStartDate().toInstant().toString();
        return dto;
    }

    /** Enforce "blockPreviousMonths" and "blockJql" rules from config. */
    private void enforceRules(Issue issue, Date started) throws Exception {
        TrockConfig cfg = configService.load();

        if (cfg.getBlockPreviousMonths() > 0 && started != null) {
            LocalDate startedDay = started.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate cutoff = LocalDate.now().withDayOfMonth(1).minusMonths(cfg.getBlockPreviousMonths() - 1L);
            if (startedDay.isBefore(cutoff)) {
                throw new SecurityException("Logging is blocked before " + cutoff);
            }
        }

        if (cfg.getBlockJql() != null && !cfg.getBlockJql().trim().isEmpty()) {
            JqlQueryParser parser = ComponentAccessor.getComponent(JqlQueryParser.class);
            SearchService search = ComponentAccessor.getComponent(SearchService.class);
            ApplicationUser caller = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser();
            String jql = "(" + cfg.getBlockJql() + ") AND issuekey = " + issue.getKey();
            Query q = parser.parseQuery(jql);
            long count = search.searchCount(caller, q);
            if (count > 0) {
                throw new SecurityException("Logging is forbidden for this issue by admin rule");
            }
        }
    }

    public boolean isManager(ApplicationUser user) {
        TrockConfig cfg = configService.load();
        if (cfg.getManagerGroup() == null || cfg.getManagerGroup().isEmpty()) return false;
        return ComponentAccessor.getGroupManager().isUserInGroup(user, cfg.getManagerGroup());
    }
}
