package com.example.trock.config;

import com.atlassian.sal.api.pluginsettings.PluginSettings;
import com.atlassian.sal.api.pluginsettings.PluginSettingsFactory;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;

import javax.inject.Inject;
import javax.inject.Named;

@Named
public class TrockConfigService {

    private static final String NS = "com.example.trock.config";
    private static final String KEY_BLOCK_MONTHS = NS + ".blockPreviousMonths";
    private static final String KEY_BLOCK_JQL    = NS + ".blockJql";
    private static final String KEY_MANAGERS     = NS + ".managerGroup";

    private final PluginSettingsFactory settingsFactory;

    @Inject
    public TrockConfigService(@ComponentImport PluginSettingsFactory settingsFactory) {
        this.settingsFactory = settingsFactory;
    }

    public TrockConfig load() {
        PluginSettings s = settingsFactory.createGlobalSettings();
        TrockConfig c = new TrockConfig();
        Object months = s.get(KEY_BLOCK_MONTHS);
        c.setBlockPreviousMonths(months == null ? 0 : Integer.parseInt(months.toString()));
        c.setBlockJql((String) s.get(KEY_BLOCK_JQL));
        c.setManagerGroup((String) s.get(KEY_MANAGERS));
        return c;
    }

    public void save(TrockConfig c) {
        PluginSettings s = settingsFactory.createGlobalSettings();
        s.put(KEY_BLOCK_MONTHS, String.valueOf(c.getBlockPreviousMonths()));
        s.put(KEY_BLOCK_JQL, c.getBlockJql() == null ? "" : c.getBlockJql());
        s.put(KEY_MANAGERS, c.getManagerGroup() == null ? "" : c.getManagerGroup());
    }
}
