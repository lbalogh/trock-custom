(function ($) {
    "use strict";

    var REST = AJS.contextPath() + "/rest/trock/1.0";

    function pad(n) { return (n < 10 ? "0" : "") + n; }
    function iso(d) { return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
    function fmtSeconds(s) {
        var h = Math.floor(s / 3600);
        var m = Math.floor((s % 3600) / 60);
        return (h ? h + "h " : "") + (m ? m + "m" : (h ? "" : "0m"));
    }

    // Parse "1h 30m", "45m", "2h" into seconds
    function parseTime(str) {
        if (!str) return 0;
        var h = /(\d+)\s*h/.exec(str);
        var m = /(\d+)\s*m/.exec(str);
        return (h ? parseInt(h[1], 10) * 3600 : 0) + (m ? parseInt(m[1], 10) * 60 : 0);
    }

    function loadWorklogs() {
        var from = $("#trock-from").val();
        var to = $("#trock-to").val();
        var userKey = $("#trock-user").val() || "";
        $.ajax({
            url: REST + "/worklogs",
            data: { from: from, to: to, userKey: userKey },
            dataType: "json"
        }).done(function (rows) {
            var $tb = $("#trock-table tbody").empty();
            var total = 0;
            rows.forEach(function (r) {
                total += r.timeSpentSeconds;
                var date = (r.startedIso || "").substring(0, 10);
                var $tr = $("<tr/>")
                    .append($("<td/>").text(date))
                    .append($("<td/>").append($("<a/>")
                        .attr("href", AJS.contextPath() + "/browse/" + r.issueKey).text(r.issueKey)))
                    .append($("<td/>").text(r.issueSummary || ""))
                    .append($("<td/>").text(fmtSeconds(r.timeSpentSeconds)))
                    .append($("<td/>").text(r.comment || ""));
                $tb.append($tr);
            });
            $("#trock-total").text(fmtSeconds(total));
        }).fail(function (xhr) {
            AJS.flag({ type: "error", body: "Failed to load: " + (xhr.responseJSON && xhr.responseJSON.error || xhr.statusText) });
        });
    }

    function logWork() {
        var seconds = parseTime($("#trock-time").val());
        if (!seconds) { $("#trock-log-msg").text("Invalid time"); return; }
        var startedDate = $("#trock-started").val() || iso(new Date());
        var payload = {
            issueKey: $("#trock-issue").val(),
            seconds: seconds,
            comment: $("#trock-comment").val(),
            startedIso: new Date(startedDate + "T09:00:00").toISOString()
        };
        $.ajax({
            url: REST + "/worklogs",
            method: "POST",
            contentType: "application/json",
            data: JSON.stringify(payload)
        }).done(function () {
            $("#trock-log-msg").text("Logged ✓");
            $("#trock-issue,#trock-time,#trock-comment").val("");
            loadWorklogs();
        }).fail(function (xhr) {
            $("#trock-log-msg").text("Error: " + (xhr.responseJSON && xhr.responseJSON.error || xhr.statusText));
        });
    }

    AJS.toInit(function () {
        if (!$("#trock-app").length) return;
        // Default range = current week (Mon-Sun)
        var now = new Date();
        var day = (now.getDay() + 6) % 7; // 0=Mon
        var monday = new Date(now); monday.setDate(now.getDate() - day);
        var sunday = new Date(monday); sunday.setDate(monday.getDate() + 6);
        $("#trock-from").val(iso(monday));
        $("#trock-to").val(iso(sunday));
        $("#trock-started").val(iso(now));

        $("#trock-refresh").on("click", loadWorklogs);
        $("#trock-log").on("click", logWork);
        loadWorklogs();
    });
})(AJS.$);
