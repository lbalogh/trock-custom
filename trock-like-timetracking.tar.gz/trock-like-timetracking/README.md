# Trock-like Timetracking Plugin (Jira Data Center)

Plugin P2 pour Jira Data Center 10.x, inspiré de "TROCK Timetracking Overview And Logging".

## Fonctionnalités livrées dans ce starter

- **Page "Timetracking Overview"** accessible depuis la barre de navigation supérieure.
- **Liste des worklogs** de l'utilisateur courant sur une plage de dates (semaine par défaut).
- **Saisie rapide de worklog** depuis la page (format `1h 30m`).
- **Vue manager** : si l'utilisateur appartient au groupe configuré, il peut saisir un `userKey` pour voir les worklogs d'un autre utilisateur.
- **Admin config** (`Administration → Manage apps → Trock`) :
  - bloquer la saisie des worklogs antérieurs à N mois,
  - bloquer la saisie sur les tickets matchant une JQL (ex : `status = Closed`),
  - définir le groupe "managers".
- **Endpoints REST** :
  - `GET  /rest/trock/1.0/worklogs?from=YYYY-MM-DD&to=YYYY-MM-DD&userKey=...`
  - `POST /rest/trock/1.0/worklogs`  `{issueKey, seconds, comment, startedIso}`
  - `GET  /rest/trock/1.0/config` / `PUT /rest/trock/1.0/config`

## Prérequis

- JDK 11
- Atlassian SDK (`atlas-*` en ligne de commande) ou Maven 3.8+
- Jira Data Center 10.x en cible

## Build & run local

```bash
# Démarrer un Jira local avec le plugin installé
atlas-mvn jira:run

# OU builder seulement le .jar
atlas-mvn clean package
# => target/trock-like-timetracking-1.0.0-SNAPSHOT.jar
```

Installation sur une instance existante : `Administration → Manage apps → Upload app → .jar`.

## Structure

```
src/main/
├── java/com/example/trock/
│   ├── action/         # WebWork actions (pages)
│   ├── config/         # Modèle + service PluginSettings
│   ├── rest/           # Endpoints REST JAX-RS
│   └── service/        # Logique métier worklogs
└── resources/
    ├── atlassian-plugin.xml
    ├── i18n/trock.properties
    ├── templates/*.vm  # Velocity
    ├── js/trock.js
    └── css/trock.css
```

## À étendre ensuite

- Filtres rapides par projet / filtre sauvegardé (déjà présent dans le Trock original).
- Rendu "issues permanentes" (pin d'un ticket dans la vue même sans worklog).
- Édition / suppression de worklogs existants (UI + endpoints `PUT/DELETE`).
- Export CSV de la plage affichée.
- Tests unitaires avec `atlas-unit-test` et tests d'intégration.
- Localisation FR (`trock_fr.properties`).
- Sécuriser explicitement `PUT /config` (actuellement protégé uniquement par l'UI admin).
